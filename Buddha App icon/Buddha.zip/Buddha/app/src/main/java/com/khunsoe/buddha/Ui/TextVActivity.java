package com.khunsoe.buddha.Ui;

import android.annotation.SuppressLint;

import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.material.button.MaterialButton;

import java.util.Objects;

import com.khunsoe.buddha.Model.PostItem;
import com.khunsoe.buddha.R;

public class TextVActivity extends AppCompatActivity {
    String desc, title;
    TextView pdfView;
    TextView textView, tw;
    MaterialButton back;


    int size = 18;

    //private ProgressBar progressBar;
    @SuppressLint({"MissingInflatedId", "SetTextI18n"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_text);

        AdView mAdView = findViewById(R.id.TadView);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);

        PostItem pdft = (PostItem) getIntent().getSerializableExtra("pdft");
        title = Objects.requireNonNull(pdft).title;
        desc = Objects.requireNonNull(pdft).desc;

        back = findViewById(R.id.back);
        textView = findViewById(R.id.namef);
        textView.setText(title);
        pdfView = findViewById(R.id.wv);
        pdfView.setMovementMethod(new ScrollingMovementMethod());
        pdfView.setText(title + "\n\n" + desc);


        back.setOnClickListener(v ->
                finish());
    }

    public void pp(View view) {
        pdfView.setTextSize(+size);
        size++;
    }
    public void nn(View view) {
        pdfView.setTextSize(+size);
        size--;
    }
}