package com.khunsoe.buddha.Adapter;
import android.annotation.SuppressLint;
import android.content.*;

import android.view.*;
import android.widget.*;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.*;

import com.khunsoe.buddha.Model.PostItem;
import com.khunsoe.buddha.R;
import com.khunsoe.buddha.Ui.MainActivity;
import com.khunsoe.buddha.Ui.TextVActivity;

public class FeedAdapter extends RecyclerView.Adapter<FeedAdapter.ItemViewHolder>
{

    List<PostItem> posts,filteredposts;
    private final Context context;


    public static class ItemViewHolder extends RecyclerView.ViewHolder {
        TextView titl;

        public ItemViewHolder(View v) {
            super(v);
            titl = v.findViewById(R.id.title);
        }
    }
    public FeedAdapter(List<PostItem> list, Context context) {
        this.filteredposts = list;
        this.context = context;
    }

    @NonNull
    @Override
    public ItemViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.text_item_layout, parent, false);
        return new ItemViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ItemViewHolder holder, @SuppressLint("RecyclerView") final int position) {

        holder.titl.setText(filteredposts.get(position).title);
        holder.itemView.setOnClickListener(view -> {
            Intent i = new Intent(context, TextVActivity.class);
            i.putExtra("pdft", filteredposts.get(position));
            context.startActivity(i);
            MainActivity.showAD();
    });
    }

    @Override
    public int getItemCount() {
        return filteredposts.size();
    }

}