package com.khunsoe.buddha.Model;
import java.io.*;

public class PostItem implements Serializable
{
	public String title,
			desc,
			category;
}
