package com.khunsoe.buddha;

import androidx.appcompat.app.AppCompatActivity;

public class App {
    public static void restartApp(AppCompatActivity appCompatActivity){
        appCompatActivity.recreate();
    }
}
