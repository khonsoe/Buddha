package com.khunsoe.buddha.Model;
import java.io.*;

public class Category implements Serializable
{
	public String name,
			image;
}
