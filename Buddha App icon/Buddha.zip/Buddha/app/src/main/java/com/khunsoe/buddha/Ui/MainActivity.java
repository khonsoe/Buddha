package com.khunsoe.buddha.Ui;

import static android.content.ContentValues.TAG;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Application;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.*;

import androidx.annotation.NonNull;
import androidx.appcompat.app.*;

import android.util.Log;
import android.view.View;
import android.widget.*;
import java.util.*;

import org.jetbrains.annotations.NotNull;
import org.json.*;

import androidx.appcompat.widget.SwitchCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.airbnb.lottie.LottieAnimationView;
import com.google.android.material.appbar.CollapsingToolbarLayout;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.progressindicator.LinearProgressIndicator;

import com.khunsoe.buddha.About.AboutActivity;
import com.khunsoe.buddha.Ads.AdsConstants;
import com.khunsoe.buddha.Ads.MyApplication;
import com.khunsoe.buddha.App;
import com.khunsoe.buddha.Model.Category;
import com.khunsoe.buddha.Adapter.CategoryAdapter;
import com.khunsoe.buddha.Adapter.FeedAdapter;
import com.khunsoe.buddha.Model.PostItem;
import com.khunsoe.buddha.Networking;
import com.khunsoe.buddha.R;

import com.google.ads.mediation.admob.AdMobAdapter;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;

public class MainActivity extends AppCompatActivity
{
	String indexLink="https://raw.githubusercontent.com/khonsoe/Buddha/main/Buddha.json";
	TextView tv;
	List<Category> categoryList;
	Map<String,List<PostItem>> posts,filteredposts;
	RecyclerView rvCat, rvPDF;

	SwitchCompat switchCompat;
	boolean nightMode;
	SharedPreferences sharedPreferences;
	SharedPreferences.Editor editor;
	MaterialButton st,rest;
	public Dialog mDialog;
	MaterialButton exit;

	LinearProgressIndicator progressBar;
	TextView tw;
	LottieAnimationView im;

	CollapsingToolbarLayout ctl;
	ImageView ivCT;
	private static InterstitialAd mInterstitialAd;
	private final boolean euConsent= true;
	@SuppressLint("StaticFieldLeak")
	public static Context context;

	@SuppressLint("MissingInflatedId")
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		MobileAds.initialize(this);
		Application application = getApplication();
		((MyApplication) application).loadAd(this);
		((MyApplication) application).showAdIfAvailable();
		progressBar =findViewById(R.id.prb);
		tw =findViewById(R.id.tw);
		im =findViewById(R.id.im_error);

		rest = findViewById(R.id.restart);
		st = findViewById(R.id.setting);
		switchCompat = findViewById(R.id.change_nightmode);
		sharedPreferences = getApplicationContext().getSharedPreferences("MODE", Context.MODE_PRIVATE);
		nightMode = sharedPreferences.getBoolean("nightMode", false);
		if (nightMode) {
			switchCompat.setChecked(true);
			AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
		}else {
			AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
		}
		switchCompat.setOnClickListener(v -> {
			if (nightMode) {
				AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
				editor = sharedPreferences.edit();
				editor.putBoolean("nightMode", false);
			} else {
				AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
				editor = sharedPreferences.edit();
				editor.putBoolean("nightMode", true);
			}
			editor.commit();
		});

		tv = findViewById(R.id.tv);
		rvCat = findViewById(R.id.rvCategory);
		rvCat.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
		rvPDF = findViewById(R.id.rvPDF);
		rvPDF.setLayoutManager(new GridLayoutManager(this, 1, GridLayoutManager.VERTICAL, false));

		fetchData();

		st.setOnClickListener(v ->
				startActivity(new Intent(getApplicationContext(), AboutActivity.class)));
		rest.setOnClickListener(v ->
				App.restartApp(this));
	}
	private void fetchData(){
		Networking.getJson(indexLink, new Networking.Callback(){
			@Override
			public void onResponse(String result) {
				processJson(result);
				progressBar.setVisibility(View.GONE);
				tw.setVisibility(View.GONE);

			}

			@SuppressLint({"WrongConstant", "ShowToast"})
			@Override
			public void onError(String error) {
				progressBar.setVisibility(View.GONE);
				tw.setVisibility(View.GONE);
				im.setVisibility(View.VISIBLE);
				//Toast.makeText(getApplicationContext(), R.string.error,1).show();
			}
		});


		MobileAds.initialize(this, new OnInitializationCompleteListener() {
			@Override
			public void onInitializationComplete(@NotNull InitializationStatus initializationStatus) {
				if (euConsent){
					AdpShow();
				}else {
					AdpShowError();
				}
			}
		});
		AdView mAdView = findViewById(R.id.adView);
		AdRequest adRequest = new AdRequest.Builder().build();
		mAdView.loadAd(adRequest);
	}

	private void AdpShow() {
		AdRequest adRequest = new AdRequest.Builder().build();
		AdInterstitialAd(adRequest);
	}
	private void AdpShowError() {
		Bundle networkExtrasBundle = new Bundle();
		networkExtrasBundle.putInt("rdp", 1);
		AdRequest adRequest = new AdRequest.Builder()
				.addNetworkExtrasBundle(AdMobAdapter.class, networkExtrasBundle)
				.build();
		AdInterstitialAd(adRequest);
	}

	private void AdInterstitialAd(AdRequest adRequest) {
		com.google.android.gms.ads.interstitial.InterstitialAd.load(this, AdsConstants.INTERSTITIAL, adRequest, new InterstitialAdLoadCallback() {
			@Override
			public void onAdLoaded(@NonNull com.google.android.gms.ads.interstitial.InterstitialAd interstitialAd) {
				// The mInterstitialAd reference will be null until
				// an ad is loaded.
				mInterstitialAd = interstitialAd;
				Log.i(TAG, "onAdLoaded");
				mInterstitialAd.setFullScreenContentCallback(new FullScreenContentCallback() {
					@Override
					public void onAdDismissedFullScreenContent() {
						// Called when fullscreen content is dismissed.
						Log.d("TAG", "The ad was dismissed.");
						if (euConsent) {
							AdpShow();
						} else {
							AdpShowError();
						}
					}

					@Override
					public void onAdFailedToShowFullScreenContent(@NotNull AdError adError) {
						// Called when fullscreen content failed to show.
						Log.d("TAG", "The ad failed to show.");
					}

					@Override
					public void onAdShowedFullScreenContent() {
						mInterstitialAd = null;
						Log.d("TAG", "The ad was shown.");
					}
				});
			}

			@Override
			public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
				// Handle the error
				Log.i(TAG, loadAdError.getMessage());
				mInterstitialAd = null;
			}
		});
	}

	public static void showAD(){
		if (mInterstitialAd != null) {
			mInterstitialAd.show((Activity) MainActivity.context);
		} else {
			Log.d("TAG", "The interstitial ad wasn't ready yet.");
		}
	}
	private void loadCategories(){
		CategoryAdapter adapter=new CategoryAdapter(categoryList,MainActivity.this);
		rvCat.setAdapter(adapter);
	}

	@SuppressLint("SetTextI18n")
	public void loadPDF(String cat){
		tv.setText(cat);
		FeedAdapter adapter=new FeedAdapter(posts.get(cat),MainActivity.this);
		rvPDF.setAdapter(adapter);
	}

	@SuppressLint({"WrongConstant", "ShowToast"})
	private void processJson(String inputJson){
		categoryList=new ArrayList<>();
		posts=new HashMap<>();
		try
		{
			JSONObject jo=new JSONObject(inputJson);
			JSONArray ja=jo.getJSONArray("categories");
			JSONObject jo2;
			JSONArray ja2;
			for(int i=0;i<ja.length();i++){
				jo2=ja.getJSONObject(i);
				Category cat=new Category();
				cat.name=jo2.getString("name");
				cat.image=jo2.getString("image");
				categoryList.add(cat);

				ja2=jo.getJSONArray(cat.name);
				List<PostItem> pdfList=new ArrayList<>();
				for(int j=0;j<ja2.length();j++){
					jo2=ja2.getJSONObject(j);
					PostItem p=new PostItem();
					p.title=jo2.getString("title");
					p.desc=jo2.getString("desc");
					if(cat.name.equals("Home")){
						p.category=jo2.getString("category");
					}else{
						p.category=cat.name;
					}

					pdfList.add(p);
				}
				posts.put(cat.name,pdfList);
			}
		}
		catch (JSONException e)
		{
			Toast.makeText(getApplicationContext(),e.toString(),1).show();
		}

		loadCategories();
		loadPDF("Home");
	}


}
