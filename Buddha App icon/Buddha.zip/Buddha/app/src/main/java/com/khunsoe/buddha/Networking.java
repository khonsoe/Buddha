package com.khunsoe.buddha;

import android.os.*;
import java.io.*;
import java.net.*;

public class Networking {
	public static void getJson(String link, Callback cb){
		new GetTask(cb).execute(link);
	}
	private static class GetTask extends AsyncTask<String,Void,String> {
		HttpURLConnection httpConn;
		Callback cb=null;
		boolean error=false;
		String msg="";

		public GetTask(Callback cb){
			this.cb=cb;
		}
		@Override
		protected String doInBackground(String[] p1) {
			try {
				URL url=new URL(p1[0]);
				httpConn = (HttpURLConnection)url.openConnection();
				httpConn.setUseCaches(false);
				httpConn.setRequestMethod("GET");

				InputStream is = httpConn.getInputStream();
				BufferedReader rd = new BufferedReader(new InputStreamReader(is));
				String line;
				StringBuffer response = new StringBuffer();
				while((line = rd.readLine()) != null) {
					response.append(line);
					response.append('\n');
				}
				rd.close();
				return response.toString();
			}
			catch (Exception e) {
				error=true;
				msg=e.toString();
				return null;
			}
			finally{
				if(httpConn != null) {
					httpConn.disconnect(); 
				}
			}
		}

		@Override
		protected void onPostExecute(String result) {
			super.onPostExecute(result);
			if(cb!=null){
				if(!error){
					cb.onResponse(result);
				}else{
					cb.onError(msg);
				}
			}
		}
	}
	
	public static interface Callback {
		public void onResponse(String result);
		public void onError(String error);
	}

}
