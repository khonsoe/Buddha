package com.khunsoe.buddha.Adapter;

import android.annotation.SuppressLint;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.view.*;
import android.widget.*;
import com.bumptech.glide.*;
import java.util.*;

import com.khunsoe.buddha.Model.Category;
import com.khunsoe.buddha.R;
import com.khunsoe.buddha.Ui.MainActivity;

public class CategoryAdapter extends RecyclerView.Adapter<CategoryAdapter.ItemViewHolder>
{

    private final List<Category> categoryList;
    private final MainActivity context;

    public static class ItemViewHolder extends RecyclerView.ViewHolder {

        ImageView iv;
        TextView tv;

        public ItemViewHolder(View v) {
            super(v);
            iv = v.findViewById(R.id.iv);
            tv = v.findViewById(R.id.title);
        }
    }

    public CategoryAdapter(List<Category> list, MainActivity context) {
        this.categoryList = list;
        this.context = context;
    }

    @NonNull
    @Override
    public ItemViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.category_item_layout, parent, false);
        return new ItemViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ItemViewHolder holder, @SuppressLint("RecyclerView") final int position) {

        Glide.with(context).load(categoryList.get(position).image).into(holder.iv);

        holder.tv.setText(categoryList.get(position).name);
        holder.itemView.setOnClickListener(view ->
                context.loadPDF(categoryList.get(position).name));
    }

    @Override
    public int getItemCount() {
        return categoryList.size();
    }

}
