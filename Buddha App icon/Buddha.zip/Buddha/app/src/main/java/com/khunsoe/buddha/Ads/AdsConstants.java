package com.khunsoe.buddha.Ads;

public class AdsConstants {
    public static final String APP_ID="no";
    public static final String APP_OPEN ="ca-app-pub-2550685256430558/1534091170";
    public static final String INTERSTITIAL ="ca-app-pub-2550685256430558/4452980122";
    public static final String REWARDED ="no";
}
